#!bin/bash
for input in "$@"
do
        echo "$input"
done
